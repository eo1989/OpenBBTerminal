"""Alt context API."""
# flake8: noqa
# pylint: disable=unused-import

# Context menus
from .covid import covid_api as covid
