# Learning Materials

Key trends, people, companies, and projects to watch across the crypto landscape, with predictions for 2022 : <https://messari.io/pdf/messari-report-crypto-theses-for-2022.pdf>
