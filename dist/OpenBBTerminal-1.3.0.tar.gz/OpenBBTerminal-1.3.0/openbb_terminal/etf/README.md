# Resources

* How to invest in ETFs for beginners : <https://www.fool.com/investing/how-to-invest/etfs/>
