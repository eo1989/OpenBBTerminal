# Resources

* Forex Trading: A Beginner’s Guide : <https://www.investopedia.com/articles/forex/11/why-trade-forex.asp>
