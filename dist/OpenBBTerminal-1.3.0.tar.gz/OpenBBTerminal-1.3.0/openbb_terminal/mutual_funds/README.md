# Resources

* Trading Mutual Funds for Beginners : <https://www.investopedia.com/articles/investing/092915/trading-mutual-funds-beginners.asp>
