"""Degiro API."""

# Context not currently formatted properly
